const Icon = () => null;

export default Icon;