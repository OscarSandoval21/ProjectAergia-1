import InputWithButton from './InputWithButton';
import styles from './styles';

export { InputWithButton, styles };