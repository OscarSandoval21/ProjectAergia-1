// import Input from './input';
// import styles from './styles';
import Buttons2 from './loginButtons';

// export { Input, styles, Buttons2};

export { Buttons2 };